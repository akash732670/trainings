<?php
	
	define('WEBSITE_URL', 'http://localhost/mvc_2pm/');



?>