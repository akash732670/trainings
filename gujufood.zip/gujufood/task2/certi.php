

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script><style type="text/css">
  <style type="text/css">
  	img{
    border-right:1px solid gray;
	}

	img:last-child
	{
	    border-right:none;
	}
  </style>
</head>
<body>

<div class="container" style="border: 10px solid #4e74d4; padding: 10px;">

<div class="row">
	<div class="col-sm-10">
				
		<img src="https://upload.wikimedia.org/wikipedia/en/thumb/3/3e/Skill_India.png/220px-Skill_India.png" style="width: 100px; height: 80px; padding-right: 9px;">
		<img src="https://pursuite-production.s3.amazonaws.com/media/cms_page_media/21/NSDC%20Logo.png" style="width: 200px; height: 80px;">		
	</div>

	<div class="col-sm-2">
		<img src="learnvern logo_white.png" style="background-color: blue; width: 100%; padding: 30px;">
	</div>
</div>

	<div class="row">
		<div class="col-sm-12">
			
		<h2 class="text-center">CERTIFICATE OF TRAINING</h2>
		<p class="text-center"> <i>This is certify that</i> </p>
		<p class="text-center" style="text-decoration-line: underline;
		"><i>MR./MRS</i> <span>SHARVAN KUMAR</span></p>
		<p class="text-center">having <b>SDMS-1230989</b> has successfully completed skill training in</p>
		<h2 class="text-center">Java Developer Course</h2>
		<p class="text-center"><i>from the period</i> <b>Oct 2019 - Dec 2019</b></p>
		<p class="text-center"><i>at</i> <b>LEARNVERN PVT LTD</b> </p>
		</div>
	</div>

	<div class="row">
		<div class="col-sm-2">
			<p> <b> Date of Issue: </b></p>
			<p><b>Place:</b> 6th Floor, Arjun Tower, Shivranjani Cross Road, Ahmedabad, Gujarat 380015 </p>
		</div>

		<div class="col-sm-8">
			<center><img src="https://www.ebesucher.com/content/images/shopping/barcode.jpg" style="width: 30%;  "></center>
		</div>

		<div class="col-sm-2">

		</div>
		
	</div>
</div>
<script type="text/javascript"></script>
</body>
</html>