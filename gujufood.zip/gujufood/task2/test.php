<!DOCTYPE html>
<html lang="en">
<head>
  <title>Mark Sheet</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<!-- 	<img src="http://matric.onlinebseb.in/img/logo.jpg">
  <h2>Bordered Table</h2>
  <p>The .table-bordered class adds borders on all sides of the table and the cells:</p>            
 -->  <!-- <table class="table table-bordered">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
      </tr>
      <tr>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
      </tr>
      <tr>
        <td>July</td>
        <td>Dooley</td>
        <td>july@example.com</td>
      </tr>
    </tbody>
  </table> -->
  <table>
  	
  	<tr>
  		<td><img src="http://matric.onlinebseb.in/img/logo.jpg"></td>
  		<td><p style="color: brown; font-size: 30px;">BIHAR SCHOOL EXAMINATION BOARD, PATNA</p><h5 style="color: brown">Annual Secondary School Examination, Result - 2020</h5></td>

  	</tr>

  </table>

  <table class="table table-bordered">
  	<tr>
  		<th>Student name</th>
  		<td colspan="5">SACHIN KUMAR</td>
  	</tr>
  	<tr>
  		<th>Mother name</th>
  		<td colspan="5">SUNITA DEVI</td>
  	</tr>
  	<tr>
  		<th>Father  name</th>
  		<td colspan="5">MANOJ KUMAR</td>
  	</tr>
  	<tr>
  		<th>REG NO</th>
  		<td>72107-00011-19</td>
  		<th>Roll Code</th>
  		<td>72107</td>
  		<th>Roll No	</th>
  		<td>2000306</td>
  	</tr>
  	<tr>
		<th>Remarks	</th>  	
		<td colspan="5">1st DIVISION</td>	
  	</tr>
  	<tr>
  		<th>Subject</th>
  		<th>Full Marks</th>
  		<th>Pass Marks</th>
  		<th colspan="3">Marks Obtained</th>
  	</tr>
  </table>
</div>

</body>
</html>
