<div marginwidth="0" marginheight="0" style="margin-top:0;margin-bottom:0;padding-top:0;padding-bottom:0;width:100%!important">

<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#F5F5F5">
<tbody><tr>
<td valign="top" align="center">

<table width="600" cellpadding="0" cellspacing="0" align="center">
<tbody><tr>
<td valign="top" align="center" style="min-width:600px">


<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top" style="font-family:sans-serif;color:#f5f5f5;font-size:1px;line-height:1px">Let your friends know about it.</td>
</tr>
<tr>
<td height="29" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
</tbody></table>

<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="5">&nbsp;</td>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="left" valign="top">
<table cellpadding="0" cellspacing="0" align="left">
<tbody><tr><td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy8_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Bdac7c060" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy8_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Bdac7c060&amp;source=gmail&amp;ust=1592144196052000&amp;usg=AFQjCNGxe5pS33eoJGYspU2WnLprfrSxCA"><img src="https://ci6.googleusercontent.com/proxy/ZJxPU0wNI4bh5kKQcVE-RPwTnSXu-P1KCnQHPHfn-bBw0H5HYW5Chu824-KauP7Nkd5pW4VWXA-85Tqohg1UnrLJzOVCj8i1nwTWdEptc8qYEPBmrBs4-E-jLyYSSdafrAaDZzmnG7yT=s0-d-e1-ft#https://link.edx.org/img/573d4200498e7fac9d0c54825ee207046e13254bbda451c4/b5de641a.gif" width="110" height="52" border="0" style="display:block" alt="edX" id="m_8027666337433426257m_8043480156705281838logo" class="CToWUd"></a></td></tr>
</tbody></table>

<table cellpadding="0" cellspacing="0" align="right">
<tbody><tr>
<td height="52" align="center" valign="bottom">
<table cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2U_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Beaf1d3c1" style="font-family:'Open Sans',Arial,sans-serif;font-size:18px;line-height:21px;text-decoration:none;color:#0075b4" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2U_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Beaf1d3c1&amp;source=gmail&amp;ust=1592144196052000&amp;usg=AFQjCNFc-EeNbo-c92AbqNz39zERU5G1Rg"><span style="color:#0075b4">Courses</span></a></td>
<td align="left" valign="top" style="font-family:'Open Sans',Arial,sans-serif;font-size:18px;line-height:21px;color:#707070;padding:0 7px">|</td>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2U_cHJvZ3JhbT1hbGwmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482C6096833d" style="font-family:'Open Sans',Arial,sans-serif;font-size:18px;line-height:21px;text-decoration:none;color:#0075b4" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2U_cHJvZ3JhbT1hbGwmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482C6096833d&amp;source=gmail&amp;ust=1592144196052000&amp;usg=AFQjCNGLwFWpQSUEkTlicdX7xv3ms4VUbA"><span style="color:#0075b4">Programs</span></a></td>
<td align="left" valign="top" style="font-family:'Open Sans',Arial,sans-serif;font-size:18px;line-height:21px;color:#707070;padding:0 7px">|</td>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9jb3Vyc2VzLmVkeC5vcmcvbG9naW4_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B2cb72d9a" style="font-family:'Open Sans',Arial,sans-serif;font-size:18px;line-height:21px;text-decoration:none;color:#0075b4" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9jb3Vyc2VzLmVkeC5vcmcvbG9naW4_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B2cb72d9a&amp;source=gmail&amp;ust=1592144196052000&amp;usg=AFQjCNEPM1gw9RKDUtR54aFVc4NzPLOpaw"><span style="color:#0075b4">My Account</span></a></td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
<td width="5">&nbsp;</td>
</tr>
</tbody></table>

<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td height="30" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtND91dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B15cd3357" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtND91dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B15cd3357&amp;source=gmail&amp;ust=1592144196052000&amp;usg=AFQjCNGH_6pSk4mrKn30Z_5xj0_JJ7GJtw"><img src="https://ci4.googleusercontent.com/proxy/c-5yzOgpKrWt6g_FCfeoXhvohhu13-7sXue8carCIUSCS5RvMlwKC3MpYsE0YZ0udQ3k7YrHCokzizr9PGQYdW806Dk3yvpQmu7a=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/n/5c48d01a48ff3.gif" width="600" border="0" style="display:block;height:auto" alt="Congratulations!" class="CToWUd"></a></td>
</tr>
<tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0" bgcolor="#fffffe">
<tbody><tr>
<td align="left" valign="top" style="padding:20px">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="left" valign="top" style="padding:10px 0 20px 0;font-family:'Open Sans',Arial,sans-serif;font-size:18px;line-height:21px;text-decoration:none;color:#707070">
Congratulations niralmodi! You are now enrolled in
<a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtND91dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482C15cd3357" style="color:#0174b3;text-decoration:none" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtND91dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482C15cd3357&amp;source=gmail&amp;ust=1592144196052000&amp;usg=AFQjCNHUSWkdZGsERQ04VI2-qX5Jhtbhjg">Marketing Management</a>.
<br><br>
As a nonprofit, we rely on people like you to help spread the word about edX. Please consider sharing this course with your&nbsp;friends.
</td>
</tr>
</tbody></table>



<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="left" valign="top" style="padding:20px 0px 10px 0px">

<table width="33%" cellpadding="0" cellspacing="0" align="left">
<tbody><tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2ZhY2Vib29rL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Ba8a377a0" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2ZhY2Vib29rL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Ba8a377a0&amp;source=gmail&amp;ust=1592144196052000&amp;usg=AFQjCNG-Lw5mdcnGx_m7kOgXGg_kKeb1Hw"><img src="https://ci6.googleusercontent.com/proxy/sHeT-wN6TnKAF8uNDfkgj-CGfzu1oQnmgk2k_tKjP4eTnfP2Nky982n1khmFMMDMyg4MZeBxOg0N1FypsH4di1aevYEISlThk_FD=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41d8f8b7a48.png" width="33" border="0" style="display:block;height:auto" alt="Facebook" class="CToWUd"></a></td>
</tr>
<tr>
<td height="15" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="center" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Facebook</td>
</tr>
</tbody></table>

<div style="display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="20%" height="50" align="center" valign="middle"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2ZhY2Vib29rL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Ca8a377a0" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2ZhY2Vib29rL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Ca8a377a0&amp;source=gmail&amp;ust=1592144196053000&amp;usg=AFQjCNEp2HjrALY_VfOJ57NG6TeLHgCWFg"><img src="https://ci6.googleusercontent.com/proxy/sHeT-wN6TnKAF8uNDfkgj-CGfzu1oQnmgk2k_tKjP4eTnfP2Nky982n1khmFMMDMyg4MZeBxOg0N1FypsH4di1aevYEISlThk_FD=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41d8f8b7a48.png" width="50%" border="0" style="display:block;height:auto" alt="Facebook" class="CToWUd"></a></td>
<td width="10%">&nbsp;</td>
<td width="70%" height="50" align="left" valign="middle" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Facebook</td>
</tr>
</tbody></table>
</div>

</td>
</tr>
</tbody></table>


<table width="33%" cellpadding="0" cellspacing="0" align="left">
<tbody><tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3R3aXR0ZXIvb2ZmZXI_dXJsPWh0dHBzOi8vd3d3LmVkeC5vcmcvY291cnNlL21hcmtldGluZy1tYW5hZ2VtZW50LTQmcHViaWQ9cmEtNWMxMjdmYjE2NGY4MWFiZiZ0aXRsZT1NYXJrZXRpbmclMjBNYW5hZ2VtZW50JmN0PTEmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B04eaf98c" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3R3aXR0ZXIvb2ZmZXI_dXJsPWh0dHBzOi8vd3d3LmVkeC5vcmcvY291cnNlL21hcmtldGluZy1tYW5hZ2VtZW50LTQmcHViaWQ9cmEtNWMxMjdmYjE2NGY4MWFiZiZ0aXRsZT1NYXJrZXRpbmclMjBNYW5hZ2VtZW50JmN0PTEmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B04eaf98c&amp;source=gmail&amp;ust=1592144196053000&amp;usg=AFQjCNHs9xo2jI79gwuIp3bp1px1j0Ye-A"><img src="https://ci6.googleusercontent.com/proxy/yrK3JRFjxgYx7jG8yvxdDaO4mwZQtwUbD6Nz1EGvvx2KyJnAZpozF6fJ7WU-B6kYjsc8SscmJrxSNKVRrbJ7CLLfIWJMQAz-Fp7S=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41e1d28ffa1.png" width="72" border="0" style="display:block;height:auto" alt="" class="CToWUd"></a></td>
</tr>
<tr>
<td height="15" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="center" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Twitter</td>
</tr>
</tbody></table>

<div style="display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="20%" height="50" align="center" valign="middle"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3R3aXR0ZXIvb2ZmZXI_dXJsPWh0dHBzOi8vd3d3LmVkeC5vcmcvY291cnNlL21hcmtldGluZy1tYW5hZ2VtZW50LTQmcHViaWQ9cmEtNWMxMjdmYjE2NGY4MWFiZiZ0aXRsZT1NYXJrZXRpbmclMjBNYW5hZ2VtZW50JmN0PTEmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482C04eaf98c" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3R3aXR0ZXIvb2ZmZXI_dXJsPWh0dHBzOi8vd3d3LmVkeC5vcmcvY291cnNlL21hcmtldGluZy1tYW5hZ2VtZW50LTQmcHViaWQ9cmEtNWMxMjdmYjE2NGY4MWFiZiZ0aXRsZT1NYXJrZXRpbmclMjBNYW5hZ2VtZW50JmN0PTEmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482C04eaf98c&amp;source=gmail&amp;ust=1592144196053000&amp;usg=AFQjCNFO3zPjobY9rdcXTAuGUY9dww8o6g"><img src="https://ci6.googleusercontent.com/proxy/yrK3JRFjxgYx7jG8yvxdDaO4mwZQtwUbD6Nz1EGvvx2KyJnAZpozF6fJ7WU-B6kYjsc8SscmJrxSNKVRrbJ7CLLfIWJMQAz-Fp7S=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41e1d28ffa1.png" width="100%" border="0" style="display:block;height:auto" alt="" class="CToWUd"></a></td>
<td width="10%">&nbsp;</td>
<td width="70%" height="50" align="left" valign="middle" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Twitter</td>
</tr>
</tbody></table>
</div>

</td>
</tr>
</tbody></table>


<table width="33%" cellpadding="0" cellspacing="0" align="left">
<tbody><tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2xpbmtlZGluL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Bfd1018e6" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2xpbmtlZGluL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Bfd1018e6&amp;source=gmail&amp;ust=1592144196053000&amp;usg=AFQjCNGFdRcRqavHtKhweO544iFc6GG1hA"><img src="https://ci3.googleusercontent.com/proxy/NcBXh9tbNP58ssXsioZX6JruMcc3ySEfQIYVVPLOvlUq5VTR1DmttCwrzYc55bm56hoJq1yl_S7zyeBrtwvwkI1j8OeVa_X7xeII=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41d92c73860.png" width="60" border="0" style="display:block;height:auto" alt="" class="CToWUd"></a></td>
</tr>
<tr>
<td height="15" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="center" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">LinkedIn</td>
</tr>
</tbody></table>

<div style="display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="20%" height="50" align="center" valign="middle"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2xpbmtlZGluL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Cfd1018e6" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2xpbmtlZGluL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Cfd1018e6&amp;source=gmail&amp;ust=1592144196053000&amp;usg=AFQjCNFS4g1cdwWEPeW3GAu94CfGnai1dg"><img src="https://ci3.googleusercontent.com/proxy/NcBXh9tbNP58ssXsioZX6JruMcc3ySEfQIYVVPLOvlUq5VTR1DmttCwrzYc55bm56hoJq1yl_S7zyeBrtwvwkI1j8OeVa_X7xeII=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41d92c73860.png" width="100%" border="0" style="display:block;height:auto" alt="" class="CToWUd"></a></td>
<td width="10%">&nbsp;</td>
<td width="70%" height="50" align="left" valign="middle" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">LinkedIn</td>
</tr>
</tbody></table>
</div>

</td>
</tr>
</tbody></table>

</td>
</tr>
</tbody></table>



<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="left" valign="top" style="padding:20px 0px">

<table width="33%" cellpadding="0" cellspacing="0" align="left">
<tbody><tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL21lc3Nlbmdlci9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482Bd5037aab" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL21lc3Nlbmdlci9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482Bd5037aab&amp;source=gmail&amp;ust=1592144196053000&amp;usg=AFQjCNFnG4lZLkbKRP-1AeGPbYLE6TxgYw"><img src="https://ci4.googleusercontent.com/proxy/oHZv2e3M30toIxwYpiZzUedSVZ2dyYHjk-7Mi7Bq1KgsyrdzFfiFZTDpUiWouaUKSGBeRqXdYg7WFP3sNu-43QXra2Gwd-5ojgJe=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41d94a75967.png" width="62" border="0" style="display:block;height:auto" alt="Messenger" class="CToWUd"></td>
</tr>
<tr>
<td height="15" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="center" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Messenger</td>
</tr>
</tbody></table>

<div style="display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="20%" height="50" align="center" valign="middle"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2ZhY2Vib29rL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Da8a377a0" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2ZhY2Vib29rL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482Da8a377a0&amp;source=gmail&amp;ust=1592144196053000&amp;usg=AFQjCNE8SMzUSBJqlZcwiy2fvwQ7wIDZcQ"><img src="https://ci4.googleusercontent.com/proxy/oHZv2e3M30toIxwYpiZzUedSVZ2dyYHjk-7Mi7Bq1KgsyrdzFfiFZTDpUiWouaUKSGBeRqXdYg7WFP3sNu-43QXra2Gwd-5ojgJe=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41d94a75967.png" width="100%" border="0" style="display:block;height:auto" alt="Messenger" class="CToWUd"></a></td>
<td width="10%">&nbsp;</td>
<td width="70%" height="50" align="left" valign="middle" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Messenger</td>
</tr>
</tbody></table>
</div>

</td>
</tr>
</tbody></table>


<table width="33%" cellpadding="0" cellspacing="0" align="left">
<tbody><tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3dlY2hhdC9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B5cecbf9e" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3dlY2hhdC9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B5cecbf9e&amp;source=gmail&amp;ust=1592144196054000&amp;usg=AFQjCNHelRjeb6ZQhM12eSc4FRFXiOg3HA"><img src="https://ci4.googleusercontent.com/proxy/6YPq-drQHeEaOv5HodrXOgwB-DcdDorbst9t9a0JYbM9EHGMUhxTTLC-38NfHBGdEqVQ-vk3BaTOGPb9ZM42baEt82ClWOQX0kXF=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c42098d6479a.png" width="72" border="0" style="display:block;height:auto" alt="WeChat" class="CToWUd"></a></td>
</tr>
<tr>
<td height="15" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="center" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">WeChat</td>
</tr>
</tbody></table>

<div style="display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="20%" height="50" align="center" valign="middle"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3dlY2hhdC9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482C5cecbf9e" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3dlY2hhdC9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482C5cecbf9e&amp;source=gmail&amp;ust=1592144196054000&amp;usg=AFQjCNHoZRBFHay2prReCJ_lxiEt3fdzEA"><img src="https://ci4.googleusercontent.com/proxy/6YPq-drQHeEaOv5HodrXOgwB-DcdDorbst9t9a0JYbM9EHGMUhxTTLC-38NfHBGdEqVQ-vk3BaTOGPb9ZM42baEt82ClWOQX0kXF=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c42098d6479a.png" width="100%" border="0" style="display:block;height:auto" alt="WeChat" class="CToWUd"></a></td>
<td width="10%">&nbsp;</td>
<td width="70%" height="50" align="left" valign="middle" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">WeChat</td>
</tr>
</tbody></table>
</div>

</td>
</tr>
</tbody></table>


<table width="33%" cellpadding="0" cellspacing="0" align="left">
<tbody><tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3doYXRzYXBwL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B7a307396" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3doYXRzYXBwL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B7a307396&amp;source=gmail&amp;ust=1592144196054000&amp;usg=AFQjCNEPDEXlRrLsB0T5ETqdKiGKL3ILWw"><img src="https://ci5.googleusercontent.com/proxy/YV9Hp-1kL6nPtio1qoq7tXtOn9ZDdh7Qm14dGdFDMp_Y_TeLjK7CYfMQuJc2L3gnvZpYmZEsncmbwvMjKZYWdQAH7o6C_QpTVTJA=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c420b40490cc.png" width="60" border="0" style="display:block;height:auto" alt="WhatsApp" class="CToWUd"></a></td>
</tr>
<tr>
<td height="15" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="center" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">WhatsApp</td>
</tr>
</tbody></table>

<div style="display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="20%" height="50" align="center" valign="middle"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3doYXRzYXBwL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482C7a307396" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3doYXRzYXBwL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482C7a307396&amp;source=gmail&amp;ust=1592144196054000&amp;usg=AFQjCNFuJIQJA7tu28AFjZUtIDKtbKY5wQ"><img src="https://ci5.googleusercontent.com/proxy/YV9Hp-1kL6nPtio1qoq7tXtOn9ZDdh7Qm14dGdFDMp_Y_TeLjK7CYfMQuJc2L3gnvZpYmZEsncmbwvMjKZYWdQAH7o6C_QpTVTJA=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c420b40490cc.png" width="100%" border="0" style="display:block;height:auto" alt="WhatsApp" class="CToWUd"></a></td>
<td width="10%">&nbsp;</td>
<td width="70%" height="50" align="left" valign="middle" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">WhatsApp</td>
</tr>
</tbody></table>
</div>

</td>
</tr>
</tbody></table>

</td>
</tr>
</tbody></table>

<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="left" valign="top" style="padding:20px 0px">

<table width="33%" cellpadding="0" cellspacing="0" align="left">
<tbody><tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2dtYWlsL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B3ed31ecf" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2dtYWlsL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B3ed31ecf&amp;source=gmail&amp;ust=1592144196054000&amp;usg=AFQjCNEaWH-BmB6RPH2YkqYFiQjq0rxQ-A"><img src="https://ci3.googleusercontent.com/proxy/sSxqx5dNUzYqc-fkJ2OoKTYt9CmVggTcC2kOmGyTwGYFQzKO6eKLVyQ6DkFbkAg-n5SyVODxGVifTQisPON5ZNmAXZo82lWDcHki=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41d90dcfa9a.png" width="62" border="0" style="display:block;height:auto" alt="Gmail" class="CToWUd"></a></td>
</tr>
<tr>
<td height="17" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="center" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Gmail</td>
</tr>
</tbody></table>

<div style="display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="20%" height="50" align="center" valign="middle"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2dtYWlsL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482C3ed31ecf" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2dtYWlsL29mZmVyP3VybD1odHRwczovL3d3dy5lZHgub3JnL2NvdXJzZS9tYXJrZXRpbmctbWFuYWdlbWVudC00JnB1YmlkPXJhLTVjMTI3ZmIxNjRmODFhYmYmdGl0bGU9TWFya2V0aW5nJTIwTWFuYWdlbWVudCZjdD0xJnV0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482C3ed31ecf&amp;source=gmail&amp;ust=1592144196054000&amp;usg=AFQjCNE1hXLZlay_FMZAHVQu7BagHR-nyg"><img src="https://ci3.googleusercontent.com/proxy/sSxqx5dNUzYqc-fkJ2OoKTYt9CmVggTcC2kOmGyTwGYFQzKO6eKLVyQ6DkFbkAg-n5SyVODxGVifTQisPON5ZNmAXZo82lWDcHki=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c41d90dcfa9a.png" width="100%" border="0" style="display:block;height:auto" alt="Gmail" class="CToWUd"></a></td>
<td width="10%">&nbsp;</td>
<td width="70%" height="50" align="left" valign="middle" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Gmail</td>
</tr>
</tbody></table>
</div>

</td>
</tr>
</tbody></table>


<table width="33%" cellpadding="0" cellspacing="0" align="left">
<tbody><tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2hvdG1haWwvb2ZmZXI_dXJsPWh0dHBzOi8vd3d3LmVkeC5vcmcvY291cnNlL21hcmtldGluZy1tYW5hZ2VtZW50LTQmcHViaWQ9cmEtNWMxMjdmYjE2NGY4MWFiZiZ0aXRsZT1NYXJrZXRpbmclMjBNYW5hZ2VtZW50JmN0PTEmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B586f4026" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2hvdG1haWwvb2ZmZXI_dXJsPWh0dHBzOi8vd3d3LmVkeC5vcmcvY291cnNlL21hcmtldGluZy1tYW5hZ2VtZW50LTQmcHViaWQ9cmEtNWMxMjdmYjE2NGY4MWFiZiZ0aXRsZT1NYXJrZXRpbmclMjBNYW5hZ2VtZW50JmN0PTEmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B586f4026&amp;source=gmail&amp;ust=1592144196054000&amp;usg=AFQjCNEAjvaqYF_08RBW9-iVEknVJg23FA"><img src="https://ci5.googleusercontent.com/proxy/PSzfRxGSCAUzJATi3v2IO472LdyEgQ9r97ifb6tgHybS7RR0MAlwUfZH3hFaZ-pF6eE0KuHjps6ZkATl-4-R6I1jH74j7wy7-far=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c420d5f4cb71.png" width="50" border="0" style="display:block;height:auto" alt="Outlook" class="CToWUd"></a></td>
</tr>
<tr>
<td height="15" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="center" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Outlook</td>
</tr>
</tbody></table>

<div style="display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="20%" height="50" align="center" valign="middle"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2hvdG1haWwvb2ZmZXI_dXJsPWh0dHBzOi8vd3d3LmVkeC5vcmcvY291cnNlL21hcmtldGluZy1tYW5hZ2VtZW50LTQmcHViaWQ9cmEtNWMxMjdmYjE2NGY4MWFiZiZ0aXRsZT1NYXJrZXRpbmclMjBNYW5hZ2VtZW50JmN0PTEmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482C586f4026" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL2hvdG1haWwvb2ZmZXI_dXJsPWh0dHBzOi8vd3d3LmVkeC5vcmcvY291cnNlL21hcmtldGluZy1tYW5hZ2VtZW50LTQmcHViaWQ9cmEtNWMxMjdmYjE2NGY4MWFiZiZ0aXRsZT1NYXJrZXRpbmclMjBNYW5hZ2VtZW50JmN0PTEmdXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482C586f4026&amp;source=gmail&amp;ust=1592144196054000&amp;usg=AFQjCNEree4H163KtWhH41cvDAmPer1qwA"><img src="https://ci5.googleusercontent.com/proxy/PSzfRxGSCAUzJATi3v2IO472LdyEgQ9r97ifb6tgHybS7RR0MAlwUfZH3hFaZ-pF6eE0KuHjps6ZkATl-4-R6I1jH74j7wy7-far=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/i/5c420d5f4cb71.png" width="100%" border="0" style="display:block;height:auto" alt="Outlook" class="CToWUd"></a></td>
<td width="10%">&nbsp;</td>
<td width="70%" height="50" align="left" valign="middle" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Outlook</td>
</tr>
</tbody></table>
</div>

</td>
</tr>
</tbody></table>


<table width="33%" cellpadding="0" cellspacing="0" align="left">
<tbody><tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3JlZGRpdC9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B5a0f8e53" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3JlZGRpdC9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B5a0f8e53&amp;source=gmail&amp;ust=1592144196054000&amp;usg=AFQjCNGNp60OssJST9POOBjmbAaf8hai7Q"><img src="https://ci6.googleusercontent.com/proxy/96O94HAgznyf9rGTOW8oaOoKpkg2o2E6hCPbVK-aTbqsQ1ODCjsI7niKaLa-LvAJB_tCTf2E8CLZaCuCsv5DK9l8hUOheSTFbuAz=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/n/5c48d26e56fff.png" width="60" border="0" style="display:block;height:auto" alt="Email" class="CToWUd"></a></td>
</tr>
<tr>
<td height="4" style="line-height:1px;font-size:1px">&nbsp;</td>
</tr>
<tr>
<td align="center" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:18px">Reddit</td>
</tr>
</tbody></table>

<div style="display:none;float:left;overflow:hidden;width:0;max-height:0;line-height:0">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="20%" height="50" align="center" valign="middle"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3JlZGRpdC9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482C5a0f8e53" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9hcGkuYWRkdGhpcy5jb20vb2V4Y2hhbmdlLzAuOC9mb3J3YXJkL3JlZGRpdC9vZmZlcj91cmw9aHR0cHM6Ly93d3cuZWR4Lm9yZy9jb3Vyc2UvbWFya2V0aW5nLW1hbmFnZW1lbnQtNCZwdWJpZD1yYS01YzEyN2ZiMTY0ZjgxYWJmJnRpdGxlPU1hcmtldGluZyUyME1hbmFnZW1lbnQmY3Q9MSZ1dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482C5a0f8e53&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNFnYzklsBUtENaunaEAqdCOhKrPcg"><img src="https://ci6.googleusercontent.com/proxy/96O94HAgznyf9rGTOW8oaOoKpkg2o2E6hCPbVK-aTbqsQ1ODCjsI7niKaLa-LvAJB_tCTf2E8CLZaCuCsv5DK9l8hUOheSTFbuAz=s0-d-e1-ft#https://media.sailthru.com/595/1k3/1/n/5c48d26e56fff.png" width="100%" border="0" style="display:block;height:auto" alt="Email" class="CToWUd"></a></td>
<td width="10%">&nbsp;</td>
<td width="70%" height="50" align="left" valign="middle" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:18px;line-height:21px">Reddit</td>
</tr>
</tbody></table>
</div>

</td>
</tr>
</tbody></table>

</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>


<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr><td height="30" style="line-height:1px;font-size:1px">&nbsp;</td></tr>
<tr>
<td align="left" valign="top">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody><tr><td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy8_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Cdac7c060" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy8_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Cdac7c060&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNGLEAncADk1N4f1Nj2hsE6DPbkhbQ"><img src="https://ci3.googleusercontent.com/proxy/yvyQw6wJlrV-jZQgF7TevR4TF31_I_jB4fK9k8ATD4jRgi2ri5VifxRZysbvyzyvMQYPW8QDAiY3Ly5Y2v5AaqLZ0nqoFswjsziu_cvl5jO6N6hucWKEgDgF4xKrFpUo0Ah4aBs=s0-d-e1-ft#https://prod-edxapp.edx-cdn.org/static/edx.org/images/logo-footer.fde85fe42f6b.png" width="110" height="52" border="0" style="display:block" alt="" class="CToWUd"></a></td></tr>
<tr><td height="30" style="line-height:1px;font-size:1px">&nbsp;</td></tr>

<tr>
<td align="left" valign="top">
<table cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="15">&nbsp;</td>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly90d2l0dGVyLmNvbS9lZFhPbmxpbmU_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B35eb58c1" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly90d2l0dGVyLmNvbS9lZFhPbmxpbmU_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B35eb58c1&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNG8GdawD9N7DlZRDff3LruTVoQWbg"><img src="https://ci3.googleusercontent.com/proxy/oN31B1XOBq1e1_T6EAtpBnHOTSxYaa7CoS2OLvZiYiBJiE5HnY4tyTo3Z7ocmsgPESLybTvzKa45o9tGcuRDgjgx5hpq0RSU96zg=s0-d-e1-ft#https://media.sailthru.com/595/1k2/b/7/5be3395300a00.png" width="40" border="0" style="display:block;height:auto" alt="Twitter" class="CToWUd"></a></td>
<td width="15">&nbsp;</td>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cDovL3d3dy5saW5rZWRpbi5jb20vY29tcGFueS9lZHg_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B372c1db0" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cDovL3d3dy5saW5rZWRpbi5jb20vY29tcGFueS9lZHg_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482B372c1db0&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNHT8Jy4p7Egh6VbLL0daqCB75f38g"><img src="https://ci6.googleusercontent.com/proxy/VLMeJDZKAxqRVTbnfNd2GpPPRlP2x5cNjPofhygC5YDxhITq1YSCAvFZxGjihXFehuvFOgZayoI_M1SDCIB9smusHTFABYXIKi-M=s0-d-e1-ft#https://media.sailthru.com/595/1k2/b/7/5be3397de9f8e.png" width="40" border="0" style="display:block;height:auto" alt="LinkedIn" class="CToWUd"></a></td>
<td width="15">&nbsp;</td>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cDovL3d3dy5mYWNlYm9vay5jb20vRWR4T25saW5lP3V0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B338e8427" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cDovL3d3dy5mYWNlYm9vay5jb20vRWR4T25saW5lP3V0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B338e8427&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNEn_TqueCORKTagQ34vW5Ltl69HaA"><img src="https://ci5.googleusercontent.com/proxy/puYGzSORGLh-77HlZJUvdEb0lBnFwEFO5OxaHF69oARqiRsCvqfTPfQrKbzvqsuSuJvQe_TUkvO7Jw2aZN1IKzzuscXTyuq360DT=s0-d-e1-ft#https://media.sailthru.com/595/1k2/b/7/5be339a32fc31.png" width="40" border="0" style="display:block;height:auto" alt="Facebook" class="CToWUd"></a></td>
<td width="15">&nbsp;</td>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS9lZHhvbmxpbmUvP3V0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B9192bb90" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS9lZHhvbmxpbmUvP3V0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B9192bb90&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNH8HyLhekjJU7zLgUip_9BqLV_fjw"><img src="https://ci6.googleusercontent.com/proxy/GJArzIjoRKG16uGQeuie2heLxURzZk5OyGcdxHtz-pJjtz12jPwwizf_2eKoxo0AtrJX4vlj7V53ADVgZ-a4dW6wzeVSImiCkXEL=s0-d-e1-ft#https://media.sailthru.com/595/1k3/5/3/5ccc7c9a76b04.jpg" width="40" border="0" style="display:block;height:auto" alt="Instagram" class="CToWUd"></a></td>
<td width="15">&nbsp;</td>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cDovL3d3dy5yZWRkaXQuY29tL3IvZWR4P3V0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B424c7582" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cDovL3d3dy5yZWRkaXQuY29tL3IvZWR4P3V0bV9zb3VyY2U9c2FpbHRocnUmdXRtX21lZGl1bT1lbWFpbCZ1dG1fY2FtcGFpZ249dHJpZ2dlcmVkX3NoYXJlaXQ/573d4200498e7fac9d0c5482B424c7582&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNGPwchGbgstFyQI9I8lLeq2jhTnAQ"><img src="https://ci4.googleusercontent.com/proxy/QNqUEFoJsSRGHd-o8HEO9vtOpH1ftmIB_iQ-6kSBzqmjgnMGS1dVerknKbbsa4Fe6M_6gezbl5xnCdG9WlOpx9frOfAw7j2hTnir=s0-d-e1-ft#https://media.sailthru.com/595/1k2/b/7/5be339cbc452e.png" width="40" border="0" style="display:block;height:auto" alt="Reddit" class="CToWUd"></a></td>
</tr>
</tbody></table>
</td>
</tr>
<tr><td height="10" style="line-height:1px;font-size:1px">&nbsp;</td></tr>

<tr>
<td align="left" valign="top">
<table cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9lZHguYXBwLmxpbmsvZW1haWwtYXBwLWluc3RhbGw_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Bf0dcd52b" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9lZHguYXBwLmxpbmsvZW1haWwtYXBwLWluc3RhbGw_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Bf0dcd52b&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNFB5ZV2ovymhKl5DL8XdOJ8umf_9A"><img src="https://ci5.googleusercontent.com/proxy/_dvZfH-a0QVqPgz9EGtYiHyXLJFd0ie1nk9PP3-W_6BfLNQDYyflS77Rb2PAoaoRGtT6wSAkkV-NuHNZbFz3KK5XHsCSwLvWzKLv=s0-d-e1-ft#https://media.sailthru.com/595/1k2/b/7/5be338f1d96e3.png" width="126" border="0" style="display:block;height:auto" alt="Download edX's App" class="CToWUd"></a></td>
<td width="15">&nbsp;</td>
<td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9lZHguYXBwLmxpbmsvZW1haWwtYXBwLWluc3RhbGw_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Cf0dcd52b" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9lZHguYXBwLmxpbmsvZW1haWwtYXBwLWluc3RhbGw_dXRtX3NvdXJjZT1zYWlsdGhydSZ1dG1fbWVkaXVtPWVtYWlsJnV0bV9jYW1wYWlnbj10cmlnZ2VyZWRfc2hhcmVpdA/573d4200498e7fac9d0c5482Cf0dcd52b&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNEdI6bKGTFPsNzwRQQik9-9KMUoqQ"><img src="https://ci6.googleusercontent.com/proxy/IX3z3QHFHWsDO9d-fpcr4pLndb4oxMKEFnDBOrVjrthGB1grcbtyX0c8dCDiQU-tjWcqGQi_UofZXbUFLglpTiFhSw_rrB6XB2w0=s0-d-e1-ft#https://media.sailthru.com/595/1k2/b/7/5be33880e3f90.png" width="126" border="0" style="display:block;height:auto" alt="Download edX's Google Play App" class="CToWUd"></a></td>
</tr>
</tbody></table>
</td>
</tr>
<tr><td height="30" style="line-height:1px;font-size:1px">&nbsp;</td></tr>
<tr><td align="left" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:14px;line-height:17px">edX is the trusted platform for education and learning.</td></tr>
<tr><td height="20" style="line-height:1px;font-size:1px">&nbsp;</td></tr>
<tr><td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9iZW5lZml0cy1vZi1idW5kbGluZz91dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B9c9b3be3" style="font-family:'Open Sans',Arial,sans-serif;font-size:14px;line-height:17px;text-decoration:none;color:#414141;font-weight:bold" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly93d3cuZWR4Lm9yZy9iZW5lZml0cy1vZi1idW5kbGluZz91dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B9c9b3be3&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNH_kaQomE16oeHMj9hFmqFUHJsvvg"><span style="color:#414141">Save 10% on select programs!</span> <span style="color:#0075b4">Click here.</span></a></td></tr>
<tr><td height="20" style="line-height:1px;font-size:1px">&nbsp;</td></tr>
<tr><td align="left" valign="top"><a href="https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9idXNpbmVzcy5lZHgub3JnLz91dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B5f97b754" style="font-family:'Open Sans',Arial,sans-serif;font-size:14px;line-height:17px;text-decoration:none;color:#707070" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/click/5ee207046e13254bbda451c4/aHR0cHM6Ly9idXNpbmVzcy5lZHgub3JnLz91dG1fc291cmNlPXNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPXRyaWdnZXJlZF9zaGFyZWl0/573d4200498e7fac9d0c5482B5f97b754&amp;source=gmail&amp;ust=1592144196055000&amp;usg=AFQjCNFwHwtGCEHWUXzXYTTP8RNi0TObcQ"><span style="color:#707070"><span style="color:#0075b4">edX for Business</span> — eLearning Solutions for Your Company</span></a></td></tr>
<tr><td height="20" style="line-height:1px;font-size:1px">&nbsp;</td></tr>
<tr><td align="left" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:14px;line-height:17px">© 2020 edX Inc. All rights reserved.</td></tr>
<tr><td height="20" style="line-height:1px;font-size:1px">&nbsp;</td></tr>
<tr><td align="left" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:14px;line-height:17px"><a href="https://link.edx.org/view/573d4200498e7fac9d0c54825ee207046e13254bbda451c4/279ba045" style="font-family:'Open Sans',Arial,sans-serif;font-size:14px;line-height:17px;text-decoration:none;color:#707070" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/view/573d4200498e7fac9d0c54825ee207046e13254bbda451c4/279ba045&amp;source=gmail&amp;ust=1592144196056000&amp;usg=AFQjCNHGEBquJYZvR4y8t9NnVULAvLEIIg"><span style="color:#707070">View on Web</span></a> | <a href="https://link.edx.org/oc/573d4200498e7fac9d0c54825ee207046e13254bbda451c4/019942b7" style="font-family:'Open Sans',Arial,sans-serif;font-size:14px;line-height:17px;text-decoration:none;color:#707070" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://link.edx.org/oc/573d4200498e7fac9d0c54825ee207046e13254bbda451c4/019942b7&amp;source=gmail&amp;ust=1592144196056000&amp;usg=AFQjCNHeRSznI8i4VEn0nL8f3i4lWzXM8g"><span style="color:#707070">Unsubscribe</span></a></td></tr>
<tr><td height="20" style="line-height:1px;font-size:1px">&nbsp;</td></tr>
<tr><td align="left" valign="top" style="font-family:'Open Sans',Arial,sans-serif;color:#707070;font-size:14px;line-height:17px">141 Portland St. 9th Floor, Cambridge, MA 02139</td></tr>
<tr><td height="30" style="line-height:1px;font-size:1px">&nbsp;</td></tr>
</tbody></table>
</td>
</tr>
</tbody></table>

</td>
</tr>
<tr>
<td align="center" valign="top"><img src="https://ci6.googleusercontent.com/proxy/ZJxPU0wNI4bh5kKQcVE-RPwTnSXu-P1KCnQHPHfn-bBw0H5HYW5Chu824-KauP7Nkd5pW4VWXA-85Tqohg1UnrLJzOVCj8i1nwTWdEptc8qYEPBmrBs4-E-jLyYSSdafrAaDZzmnG7yT=s0-d-e1-ft#https://link.edx.org/img/573d4200498e7fac9d0c54825ee207046e13254bbda451c4/b5de641a.gif" width="1" height="1" border="0" style="display:block" alt="" class="CToWUd"></td>
</tr>
<tr>
<td>
<div style="display:none;white-space:nowrap;font:15px courier;line-height:0">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>
</td>
</tr>
</tbody></table>

</td>
</tr>
</tbody></table><div class="yj6qo"></div><div class="adL">

</div></div>