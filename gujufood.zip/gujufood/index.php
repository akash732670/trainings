<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<a href="admin">Admin</a>

</body>
</html>